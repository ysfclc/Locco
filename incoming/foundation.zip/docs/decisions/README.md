# ADR index

ADRs are append-only. Supersede decisions with a new ADR; never erase rejected alternatives.

| ADR | Decision | Status |
|---|---|---|
| 0001 | Rust core/native shells | Accepted |
| 0002 | Single Locco repository | Accepted |
| 0003 | Local-first data/on-device AI | Accepted |
| 0004 | Evidence before interpretation | Accepted |
| 0005 | Selective context compiler | Accepted |
| 0006 | ZIP review gate | Accepted |
| 0007 | Native workspace | Accepted |
| 0008 | Local relational store and derived indexes | Accepted for foundation; implementation deferred |
| 0009 | Android native stack and build baseline | Accepted |
| 0010 | Authorization-aware source adapters | Accepted |
| 0011 | CI trust boundary and release gates | Accepted |
